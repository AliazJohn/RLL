export interface cart{
    cartId: number;
    userId:number;
    medicineId:number;
    medicineName:string;
    description:string;
    price:number;
}